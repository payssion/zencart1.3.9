<?php
/**
 *
 * @package initSystem
 * @copyright Copyright 2003-2010 Zen Cart Development Team
 * @license http://www.zen-cart.com/license/2_0.txt GNU Public License V2.0
 * @version $Id: init_sanitize.php 18043 2010-10-24 17:00:40Z drbyte $
 */

// ** NOTE: THIS FILE CAN BE DELETED. It is no longer needed.